let currentTabId = null;
let isTakingScreenshot = false;
let isRecording = false;

// Initialize when popup opens
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Get current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    currentTabId = tab.id;

    // Inject content script if not already injected
    try {
      await chrome.scripting.executeScript({
        target: { tabId: currentTabId },
        files: ['content.js']
      });
    } catch (error) {
      console.log('Content script already injected or injection failed:', error);
    }

    // Set up event listeners
    document.getElementById('screenshotBtn').addEventListener('click', takeScreenshot);
    document.getElementById('recordBtn').addEventListener('click', toggleRecording);

    // Check if recording is in progress
    chrome.runtime.sendMessage({ action: 'getRecordingState' }, (response) => {
      if (response && response.isRecording) {
        isRecording = true;
        const recordBtn = document.getElementById('recordBtn');
        recordBtn.textContent = 'Stop Recording';
        recordBtn.classList.add('recording');
      }
    });
  } catch (error) {
    console.error('Error initializing popup:', error);
  }
});

// Take screenshot
async function takeScreenshot() {
  if (isTakingScreenshot) {
    console.log('Screenshot already in progress');
    return;
  }

  try {
    isTakingScreenshot = true;
    const screenshotBtn = document.getElementById('screenshotBtn');
    screenshotBtn.disabled = true;
    screenshotBtn.textContent = 'Taking Screenshot...';

    // Ensure content script is injected
    try {
      await chrome.scripting.executeScript({
        target: { tabId: currentTabId },
        files: ['content.js']
      });
    } catch (error) {
      console.log('Content script already injected or injection failed:', error);
    }

    // Small delay to ensure script is loaded
    await new Promise(resolve => setTimeout(resolve, 100));

    // Send message to content script to take screenshot
    chrome.tabs.sendMessage(currentTabId, { action: 'takeScreenshot' });
  } catch (error) {
    console.error('Error taking screenshot:', error);
    alert('Failed to take screenshot: ' + error.message);
  } finally {
    // Reset button state after a short delay
    setTimeout(() => {
      isTakingScreenshot = false;
      const screenshotBtn = document.getElementById('screenshotBtn');
      screenshotBtn.disabled = false;
      screenshotBtn.textContent = 'Take Screenshot';
    }, 1000);
  }
}

// Toggle recording
async function toggleRecording() {
  const recordBtn = document.getElementById('recordBtn');
  const isCurrentlyRecording = recordBtn.textContent === 'Stop Recording';

  try {
    if (!isCurrentlyRecording) {
      // Start recording
      recordBtn.textContent = 'Stop Recording';
      recordBtn.classList.add('recording');

      // First inject the recorder script
      try {
        await chrome.scripting.executeScript({
          target: { tabId: currentTabId },
          files: ['recorder.js']
        });
      } catch (error) {
        console.log('Recorder script already injected or injection failed:', error);
      }

      // Small delay to ensure script is loaded
      await new Promise(resolve => setTimeout(resolve, 100));

      // Then inject content script if not already injected
      try {
        await chrome.scripting.executeScript({
          target: { tabId: currentTabId },
          files: ['content.js']
        });
      } catch (error) {
        console.log('Content script already injected or injection failed:', error);
      }

      // Small delay to ensure script is loaded
      await new Promise(resolve => setTimeout(resolve, 100));

      // Send message to start recording
      chrome.runtime.sendMessage({ action: 'startRecording' });
      chrome.tabs.sendMessage(currentTabId, { action: 'startRecording' });
      isRecording = true;
    } else {
      // Stop recording
      recordBtn.textContent = 'Start Recording';
      recordBtn.classList.remove('recording');
      chrome.runtime.sendMessage({ action: 'stopRecording' });
      chrome.tabs.sendMessage(currentTabId, { action: 'stopRecording' });
      isRecording = false;
    }
  } catch (error) {
    console.error('Error toggling recording:', error);
    alert('Failed to ' + (isCurrentlyRecording ? 'stop' : 'start') + ' recording: ' + error.message);
    
    // Reset button state
    recordBtn.textContent = 'Start Recording';
    recordBtn.classList.remove('recording');
    isRecording = false;
  }
}

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'screenshotError') {
    alert('Error taking screenshot: ' + message.error);
    isTakingScreenshot = false;
    const screenshotBtn = document.getElementById('screenshotBtn');
    screenshotBtn.disabled = false;
    screenshotBtn.textContent = 'Take Screenshot';
  } else if (message.action === 'recordingError') {
    alert('Error during recording: ' + message.error);
    const recordBtn = document.getElementById('recordBtn');
    recordBtn.textContent = 'Start Recording';
    recordBtn.classList.remove('recording');
    isRecording = false;
  } else if (message.action === 'recordingStopped') {
    const recordBtn = document.getElementById('recordBtn');
    recordBtn.textContent = 'Start Recording';
    recordBtn.classList.remove('recording');
    isRecording = false;
  }
}); 