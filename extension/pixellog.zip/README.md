# Screen Capture & Recorder Chrome Extension

A Chrome extension that allows you to take screenshots and record your screen.

## Features

- Take screenshots of the current tab
- Record your screen with audio
- Modern and user-friendly interface
- Timer display during recording
- Automatic file saving with timestamps

## Installation

1. Download or clone this repository
2. Open Chrome and go to `chrome://extensions/`
3. Enable "Developer mode" in the top right corner
4. Click "Load unpacked" and select the extension directory

## Usage

### Taking Screenshots
1. Click the extension icon in your Chrome toolbar
2. Click the "Take Screenshot" button
3. The screenshot will be automatically downloaded with a timestamp

### Recording Screen
1. Click the extension icon in your Chrome toolbar
2. Click the "Start Recording" button
3. Select the screen/window/tab you want to record
4. Click "Stop Recording" when finished
5. The recording will be automatically downloaded with a timestamp

## File Formats
- Screenshots are saved as PNG files
- Recordings are saved as MP4 files

## Permissions
The extension requires the following permissions:
- `activeTab`: To capture the current tab
- `desktopCapture`: To record the screen
- `storage`: To save settings
- `downloads`: To save captured files

## Note
Make sure to allow screen recording permissions when prompted by Chrome. 