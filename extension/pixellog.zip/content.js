// Use window object to store state to prevent redeclaration
if (!window.screenshotState) {
  window.screenshotState = {
    isCapturing: false
  };
}

// Initialize screen recorder state
if (!window.recorderState) {
  window.recorderState = {
    isRecording: false
  };
}

// Initialize screen recorder
if (!window.screenRecorder) {
  window.screenRecorder = null;
}

// Listen for messages from popup and background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'takeScreenshot':
      if (!window.screenshotState.isCapturing) {
        captureScreenshot();
      } else {
        console.log('Screenshot capture already in progress');
      }
      break;

    case 'startRecording':
      if (!window.recorderState.isRecording) {
        startRecording();
      } else {
        console.log('Recording already in progress');
      }
      break;

    case 'stopRecording':
      if (window.recorderState.isRecording) {
        stopRecording();
      } else {
        console.log('No recording in progress');
      }
      break;
  }
});

// Function to start recording
async function startRecording() {
  try {
    if (window.recorderState.isRecording) {
      throw new Error('Recording already in progress');
    }

    if (!window.screenRecorder) {
      throw new Error('Screen recorder not initialized');
    }

    window.recorderState.isRecording = true;
    await window.screenRecorder.startRecording();
  } catch (error) {
    console.error('Error starting recording:', error);
    window.recorderState.isRecording = false;
    chrome.runtime.sendMessage({
      action: 'recordingError',
      error: error.message
    });
  }
}

// Function to stop recording
function stopRecording() {
  try {
    if (!window.recorderState.isRecording) {
      throw new Error('No recording in progress');
    }

    if (!window.screenRecorder) {
      throw new Error('Screen recorder not initialized');
    }

    window.screenRecorder.stopRecording();
    window.recorderState.isRecording = false;
  } catch (error) {
    console.error('Error stopping recording:', error);
    window.recorderState.isRecording = false;
    chrome.runtime.sendMessage({
      action: 'recordingError',
      error: error.message
    });
  }
}

// Function to capture screenshot
async function captureScreenshot() {
  if (window.screenshotState.isCapturing) {
    return;
  }

  window.screenshotState.isCapturing = true;
  
  try {
    // Get the current tab's viewport
    const viewport = {
      width: window.innerWidth,
      height: window.innerHeight
    };

    // Create a canvas element
    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    // Get the context
    const ctx = canvas.getContext('2d');

    // Create an image from the current viewport
    const img = new Image();
    img.src = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ action: 'captureVisibleTab' }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response || !response.dataUrl) {
          reject(new Error('Failed to capture tab: No data received'));
          return;
        }
        resolve(response.dataUrl);
      });
    });

    // Wait for the image to load
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = () => reject(new Error('Failed to load captured image'));
    });

    // Clear the canvas with white background
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw the image on the canvas
    ctx.drawImage(img, 0, 0, viewport.width, viewport.height);

    // Convert canvas to blob with better quality
    canvas.toBlob((blob) => {
      if (!blob) {
        throw new Error('Failed to create image blob');
      }

      // Create download link
      const url = URL.createObjectURL(blob);
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `screenshot-${timestamp}.png`;

      // Send message to background script to download the file
      chrome.runtime.sendMessage({
        action: 'downloadScreenshot',
        url: url,
        filename: filename
      }, (response) => {
        // Clean up the object URL after sending
        URL.revokeObjectURL(url);
        
        if (chrome.runtime.lastError) {
          console.error('Error sending download message:', chrome.runtime.lastError.message);
          chrome.runtime.sendMessage({
            action: 'screenshotError',
            error: chrome.runtime.lastError.message
          });
          return;
        }

        if (!response || !response.success) {
          const errorMsg = response?.error || 'Unknown error occurred';
          console.error('Download failed:', errorMsg);
          chrome.runtime.sendMessage({
            action: 'screenshotError',
            error: errorMsg
          });
        }
      });
    }, 'image/png', 1.0); // Use maximum quality
  } catch (error) {
    console.error('Error capturing screenshot:', error);
    chrome.runtime.sendMessage({
      action: 'screenshotError',
      error: error.message
    });
  } finally {
    // Reset the screenshot state after a short delay
    setTimeout(() => {
      window.screenshotState.isCapturing = false;
    }, 1000);
  }
} 