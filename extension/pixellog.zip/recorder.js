class ScreenRecorder {
  constructor() {
    this.mediaRecorder = null;
    this.recordedChunks = [];
    this.stream = null;
    this.isRecording = false;
  }

  async startRecording() {
    if (this.isRecording) {
      throw new Error('Recording already in progress');
    }

    try {
      // Request screen capture
      this.stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          mediaSource: 'screen',
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          frameRate: { ideal: 30 }
        },
        audio: true
      });

      // Notify background script that screen sharing has started
      chrome.runtime.sendMessage({ action: 'screenShareStarted' });

      // Check for supported MIME types
      const mimeTypes = [
        'video/mp4',
        'video/webm;codecs=vp9',
        'video/webm;codecs=vp8',
        'video/webm'
      ];

      let selectedMimeType = '';
      for (const mimeType of mimeTypes) {
        if (MediaRecorder.isTypeSupported(mimeType)) {
          selectedMimeType = mimeType;
          break;
        }
      }

      if (!selectedMimeType) {
        throw new Error('No supported MIME type found for recording');
      }

      // Create MediaRecorder
      this.mediaRecorder = new MediaRecorder(this.stream, {
        mimeType: selectedMimeType,
        videoBitsPerSecond: 2500000 // 2.5 Mbps
      });

      // Handle data available event
      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.recordedChunks.push(event.data);
        }
      };

      // Handle stop event
      this.mediaRecorder.onstop = () => {
        const blob = new Blob(this.recordedChunks, {
          type: selectedMimeType
        });

        // Create download link
        const url = URL.createObjectURL(blob);
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const extension = selectedMimeType.includes('mp4') ? 'mp4' : 'webm';
        const filename = `recording-${timestamp}.${extension}`;

        // Send message to background script to download the file
        chrome.runtime.sendMessage({
          action: 'downloadRecording',
          url: url,
          filename: filename
        }, () => {
          // Clean up
          URL.revokeObjectURL(url);
          this.recordedChunks = [];
          this.stream = null;
          this.isRecording = false;
          chrome.runtime.sendMessage({ action: 'recordingStopped' });
        });
      };

      // Handle stream ended event
      this.stream.getVideoTracks()[0].onended = () => {
        if (this.isRecording) {
          this.stopRecording();
          // Notify background script that screen sharing has ended
          chrome.runtime.sendMessage({ action: 'screenShareEnded' });
        }
      };

      // Start recording
      this.mediaRecorder.start(1000); // Collect data every second
      this.isRecording = true;
    } catch (error) {
      this.isRecording = false;
      console.error('Error starting recording:', error);
      throw error;
    }
  }

  stopRecording() {
    if (this.isRecording && this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      this.mediaRecorder.stop();
      this.stream.getTracks().forEach(track => track.stop());
      this.isRecording = false;
      // Notify background script that screen sharing has ended
      chrome.runtime.sendMessage({ action: 'screenShareEnded' });
    }
  }
}

// Initialize the screen recorder
window.screenRecorder = new ScreenRecorder(); 