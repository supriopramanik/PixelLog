let mediaRecorder;
let recordedChunks = [];

// Track active downloads to prevent duplicates
let activeDownloads = new Map();

let recordingStartTime = null;
let timerInterval = null;
let elapsedSeconds = 0;
let isRecording = false;
let isScreenSharing = false;
let currentTabId = null;

// Handle messages from popup and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Store the current tab ID if available
  if (sender && sender.tab && sender.tab.id) {
    currentTabId = sender.tab.id;
  }

  switch (message.action) {
    case 'captureVisibleTab':
      captureVisibleTab(sendResponse);
      return true;

    case 'downloadScreenshot':
      handleDownload(message.url, message.filename, false, sendResponse);
      return true;

    case 'downloadRecording':
      handleDownload(message.url, message.filename, true, sendResponse);
      return true;

    case 'startRecording':
      isRecording = true;
      if (currentTabId) {
        startRecording(currentTabId);
      }
      break;

    case 'stopRecording':
      isRecording = false;
      stopTimer();
      if (currentTabId) {
        stopRecording(currentTabId);
      }
      break;

    case 'screenShareStarted':
      isScreenSharing = true;
      if (isRecording) {
        startTimer();
      }
      break;

    case 'screenShareEnded':
      isScreenSharing = false;
      stopTimer();
      break;

    case 'getRecordingState':
      sendResponse({ isRecording, isScreenSharing });
      return true;
  }
});

// Handle download with tracking
function handleDownload(url, filename, showSaveDialog, sendResponse) {
  // Check if this exact download is already in progress
  if (activeDownloads.has(filename)) {
    console.log('Download already in progress:', filename);
    sendResponse({ success: false, error: 'Download already in progress' });
    return;
  }

  // Add to active downloads with timestamp
  activeDownloads.set(filename, Date.now());

  // Download the file
  chrome.downloads.download({
    url: url,
    filename: filename,
    saveAs: showSaveDialog
  }, (downloadId) => {
    if (chrome.runtime.lastError) {
      console.error('Download error:', chrome.runtime.lastError);
      activeDownloads.delete(filename);
      sendResponse({ success: false, error: chrome.runtime.lastError.message });
      return;
    }

    // Send initial success response
    sendResponse({ success: true, downloadId: downloadId });

    // Listen for download completion
    chrome.downloads.onChanged.addListener(function downloadListener(delta) {
      if (delta.id === downloadId) {
        if (delta.state && (delta.state.current === 'complete' || delta.state.current === 'interrupted')) {
          // Remove from active downloads
          activeDownloads.delete(filename);
          // Remove the listener
          chrome.downloads.onChanged.removeListener(downloadListener);
        }
      }
    });
  });
}

// Capture visible tab
async function captureVisibleTab(sendResponse) {
  try {
    const dataUrl = await chrome.tabs.captureVisibleTab();
    sendResponse({ dataUrl });
  } catch (error) {
    console.error('Error capturing tab:', error);
    sendResponse({ error: 'Failed to capture tab' });
  }
}

// Start screen recording
async function startRecording(tabId) {
  if (!tabId) {
    console.error('No tab ID provided for recording');
    return;
  }

  try {
    // Inject the recorder script
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['recorder.js']
    });

    // Send message to start recording
    chrome.tabs.sendMessage(tabId, { action: 'startRecording' });
  } catch (error) {
    console.error('Error starting recording:', error);
    chrome.runtime.sendMessage({ 
      action: 'recordingError', 
      error: error.message 
    });
  }
}

// Stop screen recording
function stopRecording(tabId) {
  if (!tabId) {
    console.error('No tab ID provided for stopping recording');
    return;
  }
  chrome.tabs.sendMessage(tabId, { action: 'stopRecording' });
}

// Start timer
function startTimer() {
  console.log('Starting timer');
  if (timerInterval) {
    clearInterval(timerInterval);
  }

  elapsedSeconds = 0;
  updateBadge('00:00');

  timerInterval = setInterval(() => {
    if (!isRecording || !isScreenSharing) {
      stopTimer();
      return;
    }
    elapsedSeconds++;
    const timeString = formatTime(elapsedSeconds);
    console.log('Timer update:', timeString);
    updateBadge(timeString);
  }, 1000);
}

// Stop timer
function stopTimer() {
  console.log('Stopping timer');
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
  elapsedSeconds = 0;
  updateBadge('');
}

// Format time as MM:SS
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Update badge
function updateBadge(timeString) {
  try {
    console.log('Updating badge:', timeString);
    chrome.action.setBadgeText({ text: timeString });
    chrome.action.setBadgeBackgroundColor({ color: '#f44336' });
    chrome.action.setBadgeTextColor({ color: '#ffffff' });
  } catch (error) {
    console.error('Error updating badge:', error);
  }
} 