let currentLanguage = 'en';
let translations = {};

async function loadLanguage(lang) {
  try {
    const response = await fetch(`languages/${lang}.json`);
    translations = await response.json();
    updateContent();
    updateSelectedLanguage(lang);
  } catch (error) {
    console.error('Error loading language:', error);
  }
}

function updateContent() {
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    if (translations[key]) {
      element.textContent = translations[key];
    }
  });
}

function updateSelectedLanguage(lang) {
  const selectedOption = document.querySelector(`.option[data-value="${lang}"]`);
  if (selectedOption) {
    document.querySelector('#selectedLanguage span').textContent = selectedOption.textContent;
  }
}

// Initialize language selector
document.addEventListener('DOMContentLoaded', () => {
  const selectedLanguage = document.getElementById('selectedLanguage');
  const languageOptions = document.getElementById('languageOptions');
  
  // Load saved language preference
  chrome.storage.sync.get(['language'], (result) => {
    if (result.language) {
      currentLanguage = result.language;
      updateSelectedLanguage(currentLanguage);
    }
    loadLanguage(currentLanguage);
  });

  // Toggle dropdown with animation
  selectedLanguage.addEventListener('click', (e) => {
    e.stopPropagation();
    languageOptions.classList.toggle('show');
    selectedLanguage.classList.toggle('active');
  });

  // Handle option selection
  document.querySelectorAll('.option').forEach(option => {
    option.addEventListener('click', (e) => {
      e.stopPropagation();
      const lang = e.target.getAttribute('data-value');
      currentLanguage = lang;
      chrome.storage.sync.set({ language: currentLanguage });
      loadLanguage(currentLanguage);
      languageOptions.classList.remove('show');
      selectedLanguage.classList.remove('active');
    });
  });

  // Close dropdown when clicking outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.custom-select')) {
      languageOptions.classList.remove('show');
      selectedLanguage.classList.remove('active');
    }
  });
}); 